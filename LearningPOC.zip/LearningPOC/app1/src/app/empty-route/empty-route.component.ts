import { Component } from '@angular/core';

@Component({
  selector: 'app1-empty-route',
  template: '<h1>Hello World</h1>',
})
export class EmptyRouteComponent {
}
